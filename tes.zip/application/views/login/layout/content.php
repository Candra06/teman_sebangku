<?php
    include str_replace("system", "application/views/login/content", BASEPATH)."/$content.php";
?>