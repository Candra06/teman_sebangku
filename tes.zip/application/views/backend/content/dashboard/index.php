 <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                    <div class="float-left">
                      <i class="mdi mdi-cube text-danger icon-lg"></i>
                    </div>
                    <div class="float-right">
                      <p class="mb-0 text-right">Pelanggan</p>
                      <div class="fluid-container">
                        <h3 class="font-weight-medium text-right mb-0"> </h3>  <!-- <?= $hitung_hikayat ?> -->
                      </div>
                    </div>
                  </div>
                  <p class="text-muted mt-4 mb-0">
                    <i class="mdi mdi-alert-octagon mr-1" aria-hidden="true"></i> Jumlah Judul Hikayat
                  </p>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                    <div class="float-left">
                      <i class="mdi mdi-account-location text-info icon-lg"></i>
                    </div>
                    <div class="float-right">
                      <p class="mb-0 text-right">Karyawan</p>
                      <div class="fluid-container">
                        <h3 class="font-weight-medium text-right mb-0"> </h3> <!-- <?= $hitung_akun ?> -->
                      </div>
                    </div>
                  </div>
                  <p class="text-muted mt-4 mb-0">
                    <i class="mdi mdi-bookmark-outline mr-1" aria-hidden="true"></i> Product-wise sales
                  </p>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                    <div class="float-left">
                      <i class="mdi mdi-account-location text-info icon-lg"></i>
                    </div>
                    <div class="float-right">
                      <p class="mb-0 text-right">Outlet</p>
                      <div class="fluid-container">
                        <h3 class="font-weight-medium text-right mb-0"></h3> <!-- <?= $hitung_bab ?> -->
                      </div>
                    </div>
                  </div>
                  <p class="text-muted mt-4 mb-0">
                    <i class="mdi mdi-bookmark-outline mr-1" aria-hidden="true"></i> Product-wise sales
                  </p>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                    <div class="float-left">
                      <i class="mdi mdi-account-location text-info icon-lg"></i>
                    </div>
                    <div class="float-right">
                      <p class="mb-0 text-right">Saldo</p>
                      <div class="fluid-container">
                        <h3 class="font-weight-medium text-right mb-0"></h3> <!-- <?= $hitung_bab ?> -->
                      </div>
                    </div>
                  </div>
                  <p class="text-muted mt-4 mb-0">
                    <i class="mdi mdi-bookmark-outline mr-1" aria-hidden="true"></i> Product-wise sales
                  </p>
                </div>
              </div>
            </div>
         
            
          </div>
          <!-- <div class="row">
          <div class="col-md-6 d-flex align-items-stretch grid-margin">
              <div class="row flex-grow">
                <div class="col-12">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Riwayat Aktivitas</h4>
                      <p class="card-description">
                        
                      </p>
                      <div class="table-responsive ">
                        <table class="table table-striped table-bordered data">
                          <thead>
                            <tr>    
                              <th>Tanggal</th>
                              <th>Nama Akun</th>
                              <th>Jenis Aktifitas</th>
                              <th>Keterangan</th>
                            </tr>
                          </thead>
                          <tbody>
                          <?php foreach($data as $dt) {?>
                            <tr>
                              <td><?= $dt['tanggal'];?></td>        
                              <td><?= $dt['nama'];?></td>
                              <td><?= $dt['aktivitas'];?></td>
                              <td><?= $dt['keterangan'];?></td>
                              
                            </tr>
                          <?php }?>
                          </tbody>
                        </table>
                        
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div> -->
         <!--  <div class="row">
            
          </div> -->
     

          